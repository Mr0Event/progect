<script setup>
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <img class="logoMine" src="./assets/161317.png" alt="">
  <div class="PodLogo"></div>
  <div class="str">
      <div class="pole"></div>
      <button class="cena">999$</button>
      <button class="ubrat">убрать</button>
      <button class="podarit">подарить</button>
      <img class="kart_tovar" src="./assets/bion_bolh.png" alt="">
      <h1 class="nazvanie">Название товара</h1>
  </div>
  <div class="str2">
    <div class="pole"></div>
    <button class="cena">999$</button>
    <button class="ubrat">убрать</button>
    <button class="podarit">подарить</button>
    <img class="kart_tovar" src="./assets/bion_bolh.png" alt="">
    <h1 class="nazvanie">Название товара</h1>
</div>
<div class="str3">
  <div class="pole"></div>
  <button class="cena">999$</button>
  <button class="ubrat">убрать</button>
  <button class="podarit">подарить</button>
  <img class="kart_tovar" src="./assets/bion_bolh.png" alt="">
  <h1 class="nazvanie">Название товара</h1>
</div>
<div class="str4">
  <div class="pole"></div>
  <button class="cena">999$</button>
  <button class="ubrat">убрать</button>
  <button class="podarit">подарить</button>
  <img class="kart_tovar" src="./assets/bion_bolh.png" alt="">
  <h1 class="nazvanie">Название товара</h1>
</div>


  
</template>



<style scoped>
.str{
  position: absolute;
  top: 50px;
  left: 0%;
}
.str2{
  position: absolute;
  top: 170px;
  left: 0%;
}
.str3{
  position: absolute;
  top: 290px;
  left: 0%;
}
.str4{
  position: absolute;
  top: 410px;
  left: 0%;
}


button:hover{
  transition: 1s;
}
.logoMine{
/* Rectangle 4 */

position: absolute;
width: 1028px;
height: 81px;
left: 42px;
top: 68px;


box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.PodLogo{
  /* Rectangle 4 */

position: absolute;
width: 1028px;
height: 82px;
left: 42px;
top: 68px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

z-index: -2;
}

.pole{
  /* Rectangle 436 */

position: absolute;
width: 1072px;
height: 100px;
left: 15px;
top: 142px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.cena{
/* Rectangle 428 */

box-sizing: border-box;

position: absolute;
width: 160px;
height: 35px;
left: 321px;
top: 170px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px;


/* 999 $ */


font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;
text-align: center;

color: #00D0D0;


}
.ubrat{
/* Rectangle 425 */

box-sizing: border-box;

position: absolute;
width: 160px;
height: 35px;
left: 589px;
top: 170px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px;


/* убрать */
font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;
text-align: center;

color: #000000;


}
.podarit{
/* Rectangle 463 */

box-sizing: border-box;

position: absolute;
width: 160px;
height: 35px;
left: 866px;
top: 170px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px;


/* отправить */


font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;
text-align: center;

color: #000000;


}
.kart_tovar{
/* video-igry-bionicle-heroes-473409 */

position: absolute;
width: 103px;
height: 69px;
left: 79px;
top: 147px;


border-radius: 12px;

}
.nazvanie{
/* название товара */

position: absolute;
width: 145px;
height: 34px;
left: 75px;
top: 212px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;

color: #FFFFFF;


}


</style>
