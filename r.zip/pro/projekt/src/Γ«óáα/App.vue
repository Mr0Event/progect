<script setup>
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <img class="logoMine" src="./assets/161317.png" alt="">
  <div class="PodLogo"></div>

  <div class="">
    <div class="razdel"></div>
    <div class="pole"></div>
    <h1 class="raz">Раздел с товаром</h1>
  </div>
  <div class="fon"></div>
  <img class="sam_tobar" src="./assets/bion_bolh.png" alt="">
  <button class="poloski">----</button>
  <button class="kupit">Купить</button>
  <button class="cena">199.99</button>
  <h1 class="opisanie">описание товара</h1>
  <h1 class="nazbanie">Название товара</h1>
  <img class="zvezda" src="./assets/Star 1.png" alt="">
  <h1 class="ocenka">5.0</h1>

  
</template>



<style scoped>

.fon{
  /* Rectangle 294 */

position: absolute;
width: 771px;
height: 206px;
left: 299px;
top: 178px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.sam_tobar{
/* video-igry-bionicle-heroes-473409 */

position: absolute;
width: 190px;
height: 127px;
left: 312px;
top: 191px;

background: url(video-igry-bionicle-heroes-473409.jpg);
border-radius: 12px;

}
.poloski{
/* Rectangle 428 */

box-sizing: border-box;

position: absolute;
width: 106px;
height: 27px;
left: 353px;
top: 336px;

background: rgba(0, 65, 140, 0.3);
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px;

/* ------ */


font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
text-align: center;

color: #00D0D0;


}
.kupit{
/* Rectangle 425 */

box-sizing: border-box;

position: absolute;
width: 108px;
height: 27px;
left: 892px;
top: 342px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px 0px 0px 7px;


/* Title */


font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #004D4D;


}
.cena{
/* Rectangle 295 */

box-sizing: border-box;

position: absolute;
width: 54px;
height: 27px;
left: 1000px;
top: 342px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 0px 7px 7px 0px;


/* Buy */

font-family: 'Langar';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;


}
.opisanie{
/* описание________________________________________________________________________________________________________________________________________________________________________________________________________ */

position: absolute;
width: 471px;
height: 125px;
left: 539px;
top: 221px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;

color: #00D0D0;


}
.nazbanie{
/* название товара */

position: absolute;
width: 445px;
height: 125px;
left: 539px;
top: 190px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;

color: #FFFFFF;


}
.zvezda{
/* Star 1 */

box-sizing: border-box;

position: absolute;
width: 24px;
height: 24px;
left: 532px;
top: 317px;



}
.ocenka{
/* 5.0 */

position: absolute;
width: 144px;
height: 25px;
left: 562px;
top: 317px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 16px;
line-height: 22px;

color: #FFFFFF;


}


button:hover{
  transition: 1s;
}
.logoMine{
/* Rectangle 4 */

position: absolute;
width: 1028px;
height: 81px;
left: 42px;
top: 68px;


box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.PodLogo{
  /* Rectangle 4 */

position: absolute;
width: 1028px;
height: 82px;
left: 42px;
top: 68px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

z-index: -2;
}

.razdel{
  /* Rectangle 426 */

position: absolute;
width: 238px;
height: 545px;
left: 42px;
top: 178px;
background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.pole{
/* Rectangle 569 */

box-sizing: border-box;

position: absolute;
width: 238px;
height: 27px;
left: 42px;
top: 178px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px 12px 0px 0px;

}
.raz{
/* раздел */

position: absolute;
width: 39px;
height: 17px;
left: 65px;
top: 177px;
white-space: nowrap;
font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */
text-align: center;

color: #004D4D;


}
</style>
