<script setup>
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <img class="logoMine" src="./assets/161317.png" alt="">
  <div class="PodLogo"></div>
  <div class="kartinki1">
    <img class="img_b1" src="./assets/video-igry-bionicle-heroes-473409.png" alt="">
    <img class="img_d1" src="./assets/ZwssY68.png" alt="">
    <img class="img_t1" src="./assets/161316-terrariya-2.png" alt="">
    <img class="img_m1" src="./assets/161318.png" alt="">
    <img class="img_dum1" src="./assets/doom-eternal-obzor 3.png" alt="">
    <div class="zad_img_b1"></div>
    <div class="zad_img_d1"></div>
    <div class="zad_img_t1"></div>
    <div class="zad_img_m1"></div>
    <div class="zad_img_dum1"></div>
    <div class="zad_zada_img_b1"></div>
    <div class="zad_zada_img_d1"></div>
    <div class="zad_zada_img_t1"></div>
    <div class="zad_zada_img_m1"></div>
    <div class="zad_zada_img_dum1"></div>
    <button class="bt1"></button>
    <button class="bt2"></button>
    <button class="bt3"></button>
    <button class="bt4"></button>
    <button class="bt5"></button>
    <p class="ne_buy1">Bionicle</p>
    <p class="ne_buy2">Dark souls</p>
    <p class="ne_buy3">Terraria </p>
    <p class="ne_buy4">Minecraft</p>
    <p class="ne_buy5">Doom</p>
    <button class="kup_bt1"></button>
    <button class="kup_bt2"></button>
    <button class="kup_bt3"></button>
    <button class="kup_bt4"></button>
    <button class="kup_bt5"></button>
    <p class="buy1">Buy</p>
    <p class="buy2">Buy</p>
    <p class="buy3">Buy</p>
    <p class="buy4">Buy</p>
    <p class="buy5">Buy</p>
  </div>
  <div class="kartinki2">
    <img class="img_b1" src="./assets/video-igry-bionicle-heroes-473409.png" alt="">
    <img class="img_d1" src="./assets/ZwssY68.png" alt="">
    <img class="img_t1" src="./assets/161316-terrariya-2.png" alt="">
    <img class="img_m1" src="./assets/161318.png" alt="">
    <img class="img_dum1" src="./assets/doom-eternal-obzor 3.png" alt="">
    <div class="zad_img_b1"></div>
    <div class="zad_img_d1"></div>
    <div class="zad_img_t1"></div>
    <div class="zad_img_m1"></div>
    <div class="zad_img_dum1"></div>
    <div class="zad_zada_img_b1"></div>
    <div class="zad_zada_img_d1"></div>
    <div class="zad_zada_img_t1"></div>
    <div class="zad_zada_img_m1"></div>
    <div class="zad_zada_img_dum1"></div>
    <button class="bt1"></button>
    <button class="bt2"></button>
    <button class="bt3"></button>
    <button class="bt4"></button>
    <button class="bt5"></button>
    <p class="ne_buy1">Bionicle</p>
    <p class="ne_buy2">Dark souls</p>
    <p class="ne_buy3">Terraria </p>
    <p class="ne_buy4">Minecraft</p>
    <p class="ne_buy5">Doom</p>
    <button class="kup_bt1"></button>
    <button class="kup_bt2"></button>
    <button class="kup_bt3"></button>
    <button class="kup_bt4"></button>
    <button class="kup_bt5"></button>
    <p class="buy1">Buy</p>
    <p class="buy2">Buy</p>
    <p class="buy3">Buy</p>
    <p class="buy4">Buy</p>
    <p class="buy5">Buy</p>
  </div>
  <div class="kartinki3">
    <img class="img_b1" src="./assets/video-igry-bionicle-heroes-473409.png" alt="">
    <img class="img_d1" src="./assets/ZwssY68.png" alt="">
    <img class="img_t1" src="./assets/161316-terrariya-2.png" alt="">
    <img class="img_m1" src="./assets/161318.png" alt="">
    <img class="img_dum1" src="./assets/doom-eternal-obzor 3.png" alt="">
    <div class="zad_img_b1"></div>
    <div class="zad_img_d1"></div>
    <div class="zad_img_t1"></div>
    <div class="zad_img_m1"></div>
    <div class="zad_img_dum1"></div>
    <div class="zad_zada_img_b1"></div>
    <div class="zad_zada_img_d1"></div>
    <div class="zad_zada_img_t1"></div>
    <div class="zad_zada_img_m1"></div>
    <div class="zad_zada_img_dum1"></div>
    <button class="bt1"></button>
    <button class="bt2"></button>
    <button class="bt3"></button>
    <button class="bt4"></button>
    <button class="bt5"></button>
    <p class="ne_buy1">Bionicle</p>
    <p class="ne_buy2">Dark souls</p>
    <p class="ne_buy3">Terraria </p>
    <p class="ne_buy4">Minecraft</p>
    <p class="ne_buy5">Doom</p>
    <button class="kup_bt1"></button>
    <button class="kup_bt2"></button>
    <button class="kup_bt3"></button>
    <button class="kup_bt4"></button>
    <button class="kup_bt5"></button>
    <p class="buy1">Buy</p>
    <p class="buy2">Buy</p>
    <p class="buy3">Buy</p>
    <p class="buy4">Buy</p>
    <p class="buy5">Buy</p>
  </div>
  <div class="kartinki4">
    <img class="img_b1" src="./assets/video-igry-bionicle-heroes-473409.png" alt="">
    <img class="img_d1" src="./assets/ZwssY68.png" alt="">
    <img class="img_t1" src="./assets/161316-terrariya-2.png" alt="">
    <img class="img_m1" src="./assets/161318.png" alt="">
    <img class="img_dum1" src="./assets/doom-eternal-obzor 3.png" alt="">
    <div class="zad_img_b1"></div>
    <div class="zad_img_d1"></div>
    <div class="zad_img_t1"></div>
    <div class="zad_img_m1"></div>
    <div class="zad_img_dum1"></div>
    <div class="zad_zada_img_b1"></div>
    <div class="zad_zada_img_d1"></div>
    <div class="zad_zada_img_t1"></div>
    <div class="zad_zada_img_m1"></div>
    <div class="zad_zada_img_dum1"></div>
    <button class="bt1"></button>
    <button class="bt2"></button>
    <button class="bt3"></button>
    <button class="bt4"></button>
    <button class="bt5"></button>
    <p class="ne_buy1">Bionicle</p>
    <p class="ne_buy2">Dark souls</p>
    <p class="ne_buy3">Terraria </p>
    <p class="ne_buy4">Minecraft</p>
    <p class="ne_buy5">Doom</p>
    <button class="kup_bt1"></button>
    <button class="kup_bt2"></button>
    <button class="kup_bt3"></button>
    <button class="kup_bt4"></button>
    <button class="kup_bt5"></button>
    <p class="buy1">Buy</p>
    <p class="buy2">Buy</p>
    <p class="buy3">Buy</p>
    <p class="buy4">Buy</p>
    <p class="buy5">Buy</p>
  </div>

  
</template>



<style scoped>
button:hover{
  transition: 1s;
}
.logoMine{
/* Rectangle 4 */

position: absolute;
width: 1028px;
height: 81px;
left: 42px;
top: 68px;


box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.PodLogo{
  /* Rectangle 4 */

position: absolute;
width: 1028px;
height: 82px;
left: 42px;
top: 68px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

z-index: -2;
}

.kartinki4{
  position: absolute;
  top: 450px;
  left: 0px;
}

.kartinki3{
  position: absolute;
  top: 300px;
  left: 0px;
}

.kartinki2{
  position: absolute;
  top: 150px;
  left: 0px;
}

.buy1{
  /* Buy */

position: absolute;
width: 21px;
height: 17px;
left: 175px;
top: 252px;

font-family: 'Langar';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;


  z-index: 4;
}
.buy2{
/* Buy */

position: absolute;
width: 21px;
height: 17px;
left: 386px;
top: 252px;

font-family: 'Langar';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;


  z-index: 4;
}
.buy3{
/* Buy */
position: absolute;
width: 21px;
height: 17px;
left: 599px;
top: 252px;

font-family: 'Langar';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;
  z-index: 4;
}
.buy4{
/* Buy */

position: absolute;
width: 21px;
height: 17px;
left: 810px;
top: 252px;

font-family: 'Langar';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;


  z-index: 4;
}
.buy5{
/* Buy */

position: absolute;
width: 21px;
height: 17px;
left: 1023px;
top: 252px;

font-family: 'Langar';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;


  z-index: 4;
}

.kup_bt1{
  /* Rectangle 295 */

box-sizing: border-box;

position: absolute;
width: 54px;
height: 27px;
left: 159px;
top: 258px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 0px 7px 7px 0px;
z-index: 3;

}
.kup_bt2{
/* Rectangle 432 */

box-sizing: border-box;

position: absolute;
width: 54px;
height: 27px;
left: 370px;
top: 258px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 0px 7px 7px 0px;
z-index: 3;

}
.kup_bt3{
/* Rectangle 442 */

box-sizing: border-box;

position: absolute;
width: 54px;
height: 27px;
left: 583px;
top: 258px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 0px 7px 7px 0px;
z-index: 3;

}
.kup_bt4{
/* Rectangle 535 */

box-sizing: border-box;

position: absolute;
width: 54px;
height: 27px;
left: 794px;
top: 258px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 0px 7px 7px 0px;
z-index: 3;

}
.kup_bt5{
/* Rectangle 543 */

box-sizing: border-box;

position: absolute;
width: 54px;
height: 27px;
left: 1007px;
top: 258px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 0px 7px 7px 0px;
z-index: 3;

}

.ne_buy1{
/* Title */

position: absolute;
width: 29px;
height: 17px;
left: 68px;
top: 254px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #004D4D;
 white-space: nowrap;


}
.ne_buy2{
/* Title */

position: absolute;
width: 29px;
height: 17px;
left: 279px;
top: 254px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #004D4D;
 white-space: nowrap;


}
.ne_buy3{
/* Title */

position: absolute;
width: 29px;
height: 17px;
left: 492px;
top: 254px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #004D4D;
 white-space: nowrap;


}
.ne_buy4{
/* Title */

position: absolute;
width: 29px;
height: 17px;
left: 703px;
top: 254px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #004D4D;
 white-space: nowrap;


}
.ne_buy5{
/* Title */

position: absolute;
width: 29px;
height: 17px;
left: 916px;
top: 254px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #004D4D;
 white-space: nowrap;


}

.bt1{
  /* Rectangle 425 */

box-sizing: border-box;

position: absolute;
width: 108px;
height: 27px;
left: 51px;
top: 258px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px 0px 0px 7px;

}
.bt2{
/* Rectangle 433 */

box-sizing: border-box;

position: absolute;
width: 108px;
height: 27px;
left: 262px;
top: 258px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px 0px 0px 7px;

}
.bt3{
/* Rectangle 443 */

box-sizing: border-box;

position: absolute;
width: 108px;
height: 27px;
left: 475px;
top: 258px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px 0px 0px 7px;

}
.bt4{
/* Rectangle 536 */

box-sizing: border-box;

position: absolute;
width: 108px;
height: 27px;
left: 686px;
top: 258px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px 0px 0px 7px;

}
.bt5{
/* Rectangle 544 */

box-sizing: border-box;

position: absolute;
width: 108px;
height: 27px;
left: 899px;
top: 258px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px 0px 0px 7px;

}

.img_b1{
/* video-igry-bionicle-heroes-473409 */

position: absolute;
width: 156px;
height: 66px;
left: 54px;
top: 188px;

background: url(video-igry-bionicle-heroes-473409.jpg);
border-radius: 12px;

}
.img_d1{
/* ZwssY68 */

position: absolute;
width: 156px;
height: 66px;
left: 263px;
top: 189px;

background: url(ZwssY68.jpg);
border-radius: 12px;

}
.img_t1{
/* 161316-terrariya-2 */

position: absolute;
width: 156px;
height: 66px;
left: 474px;
top: 189px;

background: url(161316-terrariya-2.jpg);
border-radius: 12px;

}
.img_m1{
/* 161318 */

position: absolute;
width: 156px;
height: 66px;
left: 688px;
top: 189px;

background: url(0.jpg);
border-radius: 12px;

}
.img_dum1{
/* doom-eternal-obzor 3 */

position: absolute;
width: 156px;
height: 66px;
left: 901px;
top: 189px;

background: url(doom-eternal-obzor.jpg);
border-radius: 12px;

}
.zad_img_b1{
/* Rectangle 581 */

position: absolute;
width: 158px;
height: 68px;
left: 53px;
top: 187px;

background: #3D5261;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -1;

}
.zad_img_d1{
/* Rectangle 582 */

position: absolute;
width: 158px;
height: 68px;
left: 262px;
top: 188px;

background: #3D5261;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -1;

}
.zad_img_t1{
/* Rectangle 583 */

position: absolute;
width: 158px;
height: 68px;
left: 473px;
top: 188px;

background: #3D5261;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -1;

}
.zad_img_m1{
  /* Rectangle 584 */

position: absolute;
width: 158px;
height: 68px;
left: 687px;
top: 188px;

background: #3D5261;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -1;

}
.zad_img_dum1{
  /* Rectangle 585 */

position: absolute;
width: 158px;
height: 68px;
left: 900px;
top: 188px;

background: #3D5261;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -1;

}
.zad_zada_img_b1{
  /* Rectangle 294 */

position: absolute;
width: 181px;
height: 109px;
left: 44px;
top: 184px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -2;


}
.zad_zada_img_d1{
  /* Rectangle 296 */

position: absolute;
width: 181px;
height: 109px;
left: 252px;
top: 184px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -2;

}
.zad_zada_img_t1{
  /* Rectangle 298 */

position: absolute;
width: 181px;
height: 109px;
left: 460px;
top: 184px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -2;

}
.zad_zada_img_m1{
  /* Rectangle 300 */

position: absolute;
width: 181px;
height: 109px;
left: 673px;
top: 184px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -2;

}
.zad_zada_img_dum1{
  /* Rectangle 302 */

position: absolute;
width: 181px;
height: 109px;
left: 889px;
top: 184px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;
z-index: -2;

}
</style>
