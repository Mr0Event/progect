<script setup>
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <img class="logoMine" src="./assets/161317.png" alt="">
  <div class="PodLogo"></div>
  <div>
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  <div class="">
    <div class="razdel"></div>
    <div class="pole"></div>
    <p class="raz">Раздел с товаром</p>
  </div>
  
  <div class="dva">
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  <div class="dva2">
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  <div class="dva3">
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  <div class="dva4">
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  <div class="dva5">
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  <div class="dva6">
    <div class="poliana"></div>
    <button class="knop"></button>
    <p class="nast">Настройка</p>
  </div>
  
</template>



<style scoped>

.dva{
  position: absolute;
  left: 0px;
  top: 80px;
}
.dva2{
  position: absolute;
  left: 0px;
  top: 160px;
}
.dva3{
  position: absolute;
  left: 0px;
  top: 240px;
}
.dva4{
  position: absolute;
  left: 0px;
  top: 320px;
}
.dva5{
  position: absolute;
  left: 0px;
  top: 400px;
}
.dva6{
  position: absolute;
  left: 0px;
  top: 480px;
}


button:hover{
  transition: 1s;
}
.logoMine{
/* Rectangle 4 */

position: absolute;
width: 1028px;
height: 81px;
left: 42px;
top: 68px;


box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.PodLogo{
  /* Rectangle 4 */

position: absolute;
width: 1028px;
height: 82px;
left: 42px;
top: 68px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

z-index: -2;
}

.razdel{
  /* Rectangle 426 */

position: absolute;
width: 238px;
height: 545px;
left: 42px;
top: 178px;

background: #1E4663;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px;

}
.pole{
/* Rectangle 569 */

box-sizing: border-box;

position: absolute;
width: 238px;
height: 27px;
left: 42px;
top: 178px;

background: #02A5A5;
border: 1px solid #00FFFF;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 12px 12px 0px 0px;

}
.raz{
/* раздел */

position: absolute;
width: 39px;
height: 17px;
left: 65px;
top: 173px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */
text-align: center;

color: #004D4D;


}
.poliana{
  /* Rectangle 570 */

box-sizing: border-box;

position: absolute;
width: 762px;
height: 65px;
left: 304px;
top: 178px;

background: rgba(0, 65, 140, 0.3);
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px;

}
.knop{
/* Rectangle 571 */

box-sizing: border-box;

position: absolute;
width: 27px;
height: 27px;
left: 322px;
top: 197px;

background: rgba(0, 65, 140, 0.3);
border: 1px solid #00D0D0;
box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
border-radius: 7px;

}
.nast{
/* название настройки */

position: absolute;
width: 123px;
height: 17px;
left: 397px;
top: 192px;

font-family: 'Ledger';
font-style: normal;
font-weight: 400;
font-size: 12px;
line-height: 17px;
/* identical to box height */

color: #00D0D0;


}
</style>
